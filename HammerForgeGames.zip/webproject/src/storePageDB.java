import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/storePageDB")
public class storePageDB extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public storePageDB() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String searchQuery = request.getParameter("search");
            String category = request.getParameter("category");
            String selectSQL;
            boolean hasWhere = false;

            StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM productTable");

            // Add WHERE clause if needed
            if ((searchQuery != null && !searchQuery.trim().isEmpty()) ||
                (category != null && !category.trim().isEmpty() && !category.equals("all"))) {
                sqlBuilder.append(" WHERE");
                hasWhere = true;
            }

            // Add search condition
            if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                sqlBuilder.append(" (LOWER(itemName) LIKE ? OR LOWER(itemDescription) LIKE ?)");
            }

            // Add category condition
            if (category != null && !category.trim().isEmpty() && !category.equals("all")) {
                if (hasWhere && searchQuery != null && !searchQuery.trim().isEmpty()) {
                    sqlBuilder.append(" AND");
                }
                sqlBuilder.append(" itemCategory = ?");
            }

            selectSQL = sqlBuilder.toString();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Set parameters
            int paramIndex = 1;
            if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                String searchPattern = "%" + searchQuery.toLowerCase() + "%";
                preparedStatement.setString(paramIndex++, searchPattern);
                preparedStatement.setString(paramIndex++, searchPattern);
            }
            if (category != null && !category.trim().isEmpty() && !category.equals("all")) {
                preparedStatement.setString(paramIndex, category);
            }

            rs = preparedStatement.executeQuery();

            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.append("[");
            boolean first = true;

            while (rs.next()) {
                if (!first) {
                    jsonBuilder.append(",");
                }
                first = false;

                double itemPrice = rs.getDouble("itemPrice");
                double itemDiscount = rs.getDouble("itemDiscount");
                double discountedPrice = itemPrice * (1 - itemDiscount);

                jsonBuilder.append("{");
                jsonBuilder.append("\"itemID\":").append(rs.getInt("itemID")).append(",");
                jsonBuilder.append("\"itemName\":\"").append(escapeJSON(rs.getString("itemName"))).append("\",");
                jsonBuilder.append("\"itemDescription\":\"").append(escapeJSON(rs.getString("itemDescription"))).append("\",");
                jsonBuilder.append("\"itemPrice\":").append(itemPrice).append(",");
                jsonBuilder.append("\"itemDiscount\":").append(itemDiscount).append(",");
                jsonBuilder.append("\"discountedPrice\":").append(discountedPrice).append(",");
                jsonBuilder.append("\"itemStock\":").append(rs.getInt("itemStock")).append(",");
                jsonBuilder.append("\"itemCategory\":\"").append(escapeJSON(rs.getString("itemCategory"))).append("\",");
                jsonBuilder.append("\"imageUrl\":\"").append(escapeJSON(rs.getString("imageUrl"))).append("\"");
                jsonBuilder.append("}");
            }

            jsonBuilder.append("]");

            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println(jsonBuilder.toString());

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("{\"error\": \"server_error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String escapeJSON(String input) {
        if (input == null) {
            return "";
        }
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\b", "\\b")
                   .replace("\f", "\\f")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}