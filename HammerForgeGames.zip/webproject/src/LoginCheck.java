import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginCheck")
public class LoginCheck extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginCheck() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            // First check if email exists and get password status
            String emailCheckSql = "SELECT password FROM customerTable WHERE email = ?";
            stmt = connection.prepareStatement(emailCheckSql);
            stmt.setString(1, email);
            rs = stmt.executeQuery();
            
            if (!rs.next()) {
                // Email doesn't exist
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println("{\"error\": \"user_not_found\"}");
                return;
            }

            // Check if password is null (reset required)
            String storedPassword = rs.getString("password");
            if (storedPassword == null) {
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println("{\"error\": \"password_reset_required\"}");
                return;
            }
            
            // Now check email and password combination
            String loginSql = "SELECT customerID, firstName, lastName FROM customerTable WHERE email = ? AND password = ?";
            stmt = connection.prepareStatement(loginSql);
            stmt.setString(1, email);
            stmt.setString(2, password);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Login successful - return user data as JSON
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println("{" +
                    "\"success\": true," +
                    "\"customerID\":" + rs.getInt("customerID") + "," +
                    "\"firstName\":\"" + rs.getString("firstName") + "\"," +
                    "\"lastName\":\"" + rs.getString("lastName") + "\"," +
                    "\"email\":\"" + email + "\"" +
                    "}");
            } else {
                // Password incorrect
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println("{\"error\": \"invalid_password\"}");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("{\"error\": \"server_error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}