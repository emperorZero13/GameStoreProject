import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String managerIdStr = request.getParameter("managerId");
        String customerIdStr = request.getParameter("customerId");
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (managerIdStr == null || customerIdStr == null) {
            response.setStatus(400);
            out.println("{\"success\": false, \"error\": \"Missing required parameters\"}");
            return;
        }

        int managerId = Integer.parseInt(managerIdStr);
        int customerId = Integer.parseInt(customerIdStr);
        
        // Verify manager has permission to delete this account
        if (customerId <= managerId) {
            response.setStatus(403);
            out.println("{\"success\": false, \"error\": \"Unauthorized to delete this account\"}");
            return;
        }

        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String sql = "DELETE FROM customerTable WHERE customerID = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, customerId);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                response.setStatus(404);
                out.println("{\"success\": false, \"error\": \"Account not found\"}");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(500);
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}