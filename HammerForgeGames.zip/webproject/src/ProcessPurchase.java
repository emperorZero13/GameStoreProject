import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProcessPurchase")
public class ProcessPurchase extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection connection = null;

        try {
            // Parse the cart items from the request
            String cartJson = request.getParameter("cart");
            List<CartItem> cartItems = parseCartJson(cartJson);

            DBConnection.getDBConnection();
            connection = DBConnection.connection;
            connection.setAutoCommit(false); // Start transaction

            String updateSQL = "UPDATE productTable SET itemStock = itemStock - ?, itemSold = itemSold + ? WHERE itemID = ?";
            PreparedStatement stmt = connection.prepareStatement(updateSQL);

            // Process each item in the cart
            for (CartItem item : cartItems) {
                stmt.setInt(1, item.quantity); // Decrease stock
                stmt.setInt(2, item.quantity); // Increase sold
                stmt.setInt(3, item.id);
                stmt.addBatch();
            }

            // Execute all updates
            stmt.executeBatch();
            connection.commit(); // Commit transaction

            out.println("{\"success\": true}");

        } catch (SQLException e) {
            try {
                if (connection != null) connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            out.println("{\"success\": false, \"error\": \"Database error\"}");
            e.printStackTrace();
        } catch (Exception e) {
            out.println("{\"success\": false, \"error\": \"Server error\"}");
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static class CartItem {
        int id;
        int quantity;

        CartItem(int id, int quantity) {
            this.id = id;
            this.quantity = quantity;
        }
    }

    private List<CartItem> parseCartJson(String json) {
        List<CartItem> items = new ArrayList<>();
        
        // Remove brackets from array
        json = json.trim().substring(1, json.length() - 1);
        
        // Split into individual objects
        String[] objects = json.split("\\},\\{");
        
        for (String obj : objects) {
            // Clean up the object string
            obj = obj.replace("{", "").replace("}", "").trim();
            
            // Parse id and quantity
            int id = 0;
            int quantity = 0;
            
            String[] pairs = obj.split(",");
            for (String pair : pairs) {
                String[] keyValue = pair.split(":");
                if (keyValue.length == 2) {
                    String key = keyValue[0].replace("\"", "").trim();
                    String value = keyValue[1].replace("\"", "").trim();
                    
                    if (key.equals("id")) {
                        id = Integer.parseInt(value);
                    } else if (key.equals("quantity")) {
                        quantity = Integer.parseInt(value);
                    }
                }
            }
            
            if (id > 0 && quantity > 0) {
                items.add(new CartItem(id, quantity));
            }
        }
        
        return items;
    }
}