import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdatePassword")
public class UpdatePassword extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (email == null || password == null) {
            response.setStatus(400);
            out.println("{\"success\": false, \"error\": \"Missing required parameters\"}");
            return;
        }

        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String sql = "UPDATE customerTable SET password = ? WHERE email = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, password);
            stmt.setString(2, email);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                response.setStatus(404);
                out.println("{\"success\": false, \"error\": \"Account not found\"}");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(500);
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}