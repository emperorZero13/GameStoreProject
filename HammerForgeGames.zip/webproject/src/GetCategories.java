import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/GetCategories")
public class GetCategories extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        Connection connection = null;
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String sql = "SELECT DISTINCT itemCategory FROM productTable WHERE itemCategory IS NOT NULL";
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            Set<String> categories = new HashSet<>();
            while (rs.next()) {
                String category = rs.getString("itemCategory");
                if (category != null && !category.trim().isEmpty()) {
                    categories.add(category.trim());
                }
            }

            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.append("[");
            boolean first = true;
            for (String category : categories) {
                if (!first) jsonBuilder.append(",");
                first = false;
                jsonBuilder.append("\"").append(escapeJSON(category)).append("\"");
            }
            jsonBuilder.append("]");

            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println(jsonBuilder.toString());

            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("[]");
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String escapeJSON(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\b", "\\b")
                   .replace("\f", "\\f")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}