import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SimpleFormInsert")
public class SimpleFormInsert extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public SimpleFormInsert() {
      super();
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) 
         throws ServletException, IOException {
      Connection connection = null;
      PreparedStatement stmt = null;
      ResultSet rs = null;

      try {
         // Validate required fields
         String firstName = validateParameter(request, "firstName");
         String lastName = validateParameter(request, "lastName");
         String phoneNumber = validateParameter(request, "phoneNumber");
         String email = validateParameter(request, "email");
         String password = validateParameter(request, "password");
         String streetAddress = validateParameter(request, "streetAddress");
         String city = validateParameter(request, "city");
         String state = validateParameter(request, "state");
         String zipCode = validateParameter(request, "zipCode");
         String cardNumber = validateParameter(request, "cardNumber");
         String cardDate = validateParameter(request, "cardDate");
         String cardCVC = validateParameter(request, "cardCVC");

         // Clean input data
         phoneNumber = phoneNumber.replaceAll("[^0-9]", "");
         cardNumber = cardNumber.replaceAll("[^0-9]", "");
         zipCode = zipCode.replaceAll("[^0-9]", "");

         // Get database connection
         try {
             DBConnection.getDBConnection();
             connection = DBConnection.connection;
         } catch (Exception e) {
             System.err.println("Database Connection Error: " + e.getMessage());
             e.printStackTrace();
             response.sendRedirect("signIn.html?error=db_connection_error");
             return;
         }

         // Check if email already exists
         String checkEmailSql = "SELECT email FROM customerTable WHERE email = ?";
         stmt = connection.prepareStatement(checkEmailSql);
         stmt.setString(1, email);
         rs = stmt.executeQuery();

         if (rs.next()) {
            response.sendRedirect("signIn.html?error=email_exists");
            return;
         }

         // Insert new customer
         String insertSql = "INSERT INTO customerTable (customerID, firstName, lastName, phoneNumber, " +
                          "email, password, streetAddress, city, state, zipCode, cardNumber, cardDate, cardCVC) " +
                          "VALUES (default, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
         
         stmt = connection.prepareStatement(insertSql);
         stmt.setString(1, firstName);
         stmt.setString(2, lastName);
         stmt.setString(3, phoneNumber);
         stmt.setString(4, email);
         stmt.setString(5, password);
         stmt.setString(6, streetAddress);
         stmt.setString(7, city);
         stmt.setString(8, state);
         stmt.setString(9, zipCode);
         stmt.setString(10, cardNumber);
         stmt.setString(11, cardDate);
         stmt.setString(12, cardCVC);

         int rowsAffected = stmt.executeUpdate();
         
         if (rowsAffected > 0) {
             response.sendRedirect("logIn.html?success=registration_complete");
         } else {
             System.err.println("Insert failed: No rows affected");
             response.sendRedirect("signIn.html?error=insert_failed");
         }

      } catch (SQLException e) {
         System.err.println("SQL Error: " + e.getMessage());
         e.printStackTrace();
         response.sendRedirect("signIn.html?error=sql_error");
      } catch (Exception e) {
         System.err.println("General Error: " + e.getMessage());
         e.printStackTrace();
         response.sendRedirect("signIn.html?error=server_error");
      } finally {
         try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (connection != null) connection.close();
         } catch (SQLException e) {
            System.err.println("Error closing resources: " + e.getMessage());
            e.printStackTrace();
         }
      }
   }

   private String validateParameter(HttpServletRequest request, String paramName) throws ServletException {
       String value = request.getParameter(paramName);
       if (value == null || value.trim().isEmpty()) {
           throw new ServletException("Missing required parameter: " + paramName);
       }
       return value.trim();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) 
         throws ServletException, IOException {
      doPost(request, response);
   }
}