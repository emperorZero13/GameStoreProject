import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProfileData")
public class ProfileData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProfileData() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String customerID = request.getParameter("customerID");
        
        if (customerID == null || customerID.trim().isEmpty()) {
            response.setStatus(400);
            response.getWriter().write("{\"error\": \"Invalid customer ID\"}");
            return;
        }

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String sql = "SELECT phoneNumber, streetAddress, city, state, zipCode, " +
                        "cardNumber, cardDate FROM customerTable WHERE customerID = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, customerID);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println("{" +
                    "\"phoneNumber\":\"" + formatPhoneNumber(rs.getString("phoneNumber")) + "\"," +
                    "\"streetAddress\":\"" + escapeJSON(rs.getString("streetAddress")) + "\"," +
                    "\"city\":\"" + escapeJSON(rs.getString("city")) + "\"," +
                    "\"state\":\"" + escapeJSON(rs.getString("state")) + "\"," +
                    "\"zipCode\":\"" + escapeJSON(rs.getString("zipCode")) + "\"," +
                    "\"cardNumber\":\"" + rs.getString("cardNumber") + "\"," +
                    "\"cardDate\":\"" + escapeJSON(rs.getString("cardDate")) + "\"" +
                    "}");
            } else {
                response.setStatus(404);
                response.getWriter().write("{\"error\": \"User not found\"}");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(500);
            response.getWriter().write("{\"error\": \"Server error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String formatPhoneNumber(String phone) {
        if (phone == null || phone.length() != 10) {
            return phone;
        }
        return "(" + phone.substring(0, 3) + ") " + 
               phone.substring(3, 6) + "-" + 
               phone.substring(6);
    }

    private String escapeJSON(String input) {
        if (input == null) {
            return "";
        }
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\b", "\\b")
                   .replace("\f", "\\f")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}