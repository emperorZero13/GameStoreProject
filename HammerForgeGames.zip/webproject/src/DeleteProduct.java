import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteProduct")
public class DeleteProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            int itemID = Integer.parseInt(request.getParameter("itemID"));

            DBConnection.getDBConnection();
            connection = DBConnection.connection;
            
            String sql = "DELETE FROM productTable WHERE itemID = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, itemID);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                out.println("{\"success\": false, \"error\": \"Product not found\"}");
            }
            
        } catch (NumberFormatException e) {
            out.println("{\"success\": false, \"error\": \"Invalid product ID\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}