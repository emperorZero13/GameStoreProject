import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            // Get parameters
            String itemName = request.getParameter("itemName");
            String itemDescription = request.getParameter("itemDescription");
            double itemPrice = Double.parseDouble(request.getParameter("itemPrice"));
            double itemDiscount = Double.parseDouble(request.getParameter("itemDiscount"));
            int itemStock = Integer.parseInt(request.getParameter("itemStock"));
            String itemCategory = request.getParameter("itemCategory");
            String imageUrl = request.getParameter("imageUrl");

            // Debug output
            System.out.println("Received parameters:");
            System.out.println("itemName: " + itemName);
            System.out.println("itemDescription: " + itemDescription);
            System.out.println("itemPrice: " + itemPrice);
            System.out.println("itemDiscount: " + itemDiscount);
            System.out.println("itemStock: " + itemStock);
            System.out.println("itemCategory: " + itemCategory);
            System.out.println("imageUrl: " + imageUrl);

            // Validate input
            if (itemName == null || itemName.trim().isEmpty() ||
                itemDescription == null || itemDescription.trim().isEmpty() ||
                itemPrice <= 0 || itemDiscount < 0 || itemDiscount > 1 ||
                itemStock < 0 || itemCategory == null || itemCategory.trim().isEmpty() ||
                imageUrl == null || imageUrl.trim().isEmpty()) {
                throw new IllegalArgumentException("Invalid input parameters");
            }

            // Insert into database
            DBConnection.getDBConnection();
            connection = DBConnection.connection;
            
            String sql = "INSERT INTO productTable (itemName, itemDescription, itemPrice, " +
                        "itemDiscount, itemStock, itemCategory, imageUrl, itemSold) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, 0)";
            
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, itemName);
            stmt.setString(2, itemDescription);
            stmt.setDouble(3, itemPrice);
            stmt.setDouble(4, itemDiscount);
            stmt.setInt(5, itemStock);
            stmt.setString(6, itemCategory);
            stmt.setString(7, imageUrl);
            
            System.out.println("Executing SQL: " + sql);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                out.println("{\"success\": false, \"error\": \"Failed to add product\"}");
            }
            
        } catch (NumberFormatException e) {
            System.err.println("Number Format Error: " + e.getMessage());
            out.println("{\"success\": false, \"error\": \"Invalid number format\"}");
        } catch (IllegalArgumentException e) {
            System.err.println("Validation Error: " + e.getMessage());
            out.println("{\"success\": false, \"error\": \"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            System.err.println("Server Error: " + e.getMessage());
            e.printStackTrace();
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                System.err.println("Error closing resources: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}