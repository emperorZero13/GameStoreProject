import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/HomePageData")
public class HomePageData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        Connection connection = null;
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            // Get top selling items (increased to 4)
            String topSellingSQL = "SELECT * FROM productTable ORDER BY itemSold DESC LIMIT 4";
            PreparedStatement topSellingStmt = connection.prepareStatement(topSellingSQL);
            ResultSet topSellingRs = topSellingStmt.executeQuery();

            // Get best deals (increased to 4)
            String bestDealsSQL = "SELECT *, (itemPrice * itemDiscount) as savingsAmount " +
                                "FROM productTable WHERE itemDiscount > 0 " +
                                "ORDER BY savingsAmount DESC LIMIT 4";
            PreparedStatement bestDealsStmt = connection.prepareStatement(bestDealsSQL);
            ResultSet bestDealsRs = bestDealsStmt.executeQuery();

            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.append("{\"topSelling\":[");

            // Process top selling items
            boolean first = true;
            while (topSellingRs.next()) {
                if (!first) jsonBuilder.append(",");
                first = false;
                appendProductJson(jsonBuilder, topSellingRs);
            }

            jsonBuilder.append("],\"bestDeals\":[");

            // Process best deals
            first = true;
            while (bestDealsRs.next()) {
                if (!first) jsonBuilder.append(",");
                first = false;
                appendProductJson(jsonBuilder, bestDealsRs);
            }

            jsonBuilder.append("]}");

            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println(jsonBuilder.toString());

            topSellingRs.close();
            bestDealsRs.close();
            topSellingStmt.close();
            bestDealsStmt.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("{\"error\": \"server_error\"}");
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void appendProductJson(StringBuilder jsonBuilder, ResultSet rs) throws Exception {
        double itemPrice = rs.getDouble("itemPrice");
        double itemDiscount = rs.getDouble("itemDiscount");
        double discountedPrice = itemPrice * (1 - itemDiscount);

        jsonBuilder.append("{");
        jsonBuilder.append("\"itemID\":").append(rs.getInt("itemID")).append(",");
        jsonBuilder.append("\"itemName\":\"").append(escapeJSON(rs.getString("itemName"))).append("\",");
        jsonBuilder.append("\"itemDescription\":\"").append(escapeJSON(rs.getString("itemDescription"))).append("\",");
        jsonBuilder.append("\"itemPrice\":").append(itemPrice).append(",");
        jsonBuilder.append("\"itemDiscount\":").append(itemDiscount).append(",");
        jsonBuilder.append("\"discountedPrice\":").append(discountedPrice).append(",");
        jsonBuilder.append("\"itemStock\":").append(rs.getInt("itemStock")).append(",");
        jsonBuilder.append("\"itemSold\":").append(rs.getInt("itemSold")).append(",");
        jsonBuilder.append("\"imageUrl\":\"").append(escapeJSON(rs.getString("imageUrl"))).append("\"");
        jsonBuilder.append("}");
    }

    private String escapeJSON(String input) {
        if (input == null) {
            return "";
        }
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\b", "\\b")
                   .replace("\f", "\\f")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}