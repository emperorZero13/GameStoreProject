import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddUser")
public class AddUser extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Get parameters
            String managerId = request.getParameter("managerId");
            String customerId = request.getParameter("customerId");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String phoneNumber = request.getParameter("phoneNumber");

            // Validate manager permissions
            if (Integer.parseInt(managerId) >= Integer.parseInt(customerId)) {
                out.println("{\"success\": false, \"error\": \"Invalid customer ID range\"}");
                return;
            }

            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            // Check if email exists
            String checkEmailSql = "SELECT email FROM customerTable WHERE email = ?";
            stmt = connection.prepareStatement(checkEmailSql);
            stmt.setString(1, email);
            rs = stmt.executeQuery();

            if (rs.next()) {
                out.println("{\"success\": false, \"error\": \"Email already exists\"}");
                return;
            }

            // Check if ID exists
            String checkIdSql = "SELECT customerID FROM customerTable WHERE customerID = ?";
            stmt = connection.prepareStatement(checkIdSql);
            stmt.setInt(1, Integer.parseInt(customerId));
            rs = stmt.executeQuery();

            if (rs.next()) {
                out.println("{\"success\": false, \"error\": \"Customer ID already exists\"}");
                return;
            }

            // Insert new user
            String insertSql = "INSERT INTO customerTable (customerID, firstName, lastName, email, password, phoneNumber) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = connection.prepareStatement(insertSql);
            stmt.setInt(1, Integer.parseInt(customerId));
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setString(4, email);
            stmt.setString(5, password);
            stmt.setString(6, phoneNumber.replaceAll("[^0-9]", ""));

            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                out.println("{\"success\": false, \"error\": \"Failed to add user\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}