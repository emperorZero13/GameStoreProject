import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/GetAccounts")
public class GetAccounts extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String managerIdStr = request.getParameter("managerId");
        
        if (managerIdStr == null) {
            response.setStatus(400);
            response.getWriter().write("{\"error\": \"Manager ID required\"}");
            return;
        }

        int managerId = Integer.parseInt(managerIdStr);
        
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            // Only fetch accounts with higher IDs than the manager's
            String sql = "SELECT customerID, firstName, lastName, email, phoneNumber FROM customerTable WHERE customerID > ? ORDER BY customerID";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, managerId);
            rs = stmt.executeQuery();
            
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.append("[");
            boolean first = true;
            
            while (rs.next()) {
                if (!first) {
                    jsonBuilder.append(",");
                }
                first = false;
                
                jsonBuilder.append("{");
                jsonBuilder.append("\"customerID\":").append(rs.getInt("customerID")).append(",");
                jsonBuilder.append("\"firstName\":\"").append(escapeJSON(rs.getString("firstName"))).append("\",");
                jsonBuilder.append("\"lastName\":\"").append(escapeJSON(rs.getString("lastName"))).append("\",");
                jsonBuilder.append("\"email\":\"").append(escapeJSON(rs.getString("email"))).append("\",");
                jsonBuilder.append("\"phoneNumber\":\"").append(escapeJSON(rs.getString("phoneNumber"))).append("\"");
                jsonBuilder.append("}");
            }
            
            jsonBuilder.append("]");
            
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println(jsonBuilder.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(500);
            response.getWriter().write("{\"error\": \"Server error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String escapeJSON(String input) {
        if (input == null) {
            return "";
        }
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\b", "\\b")
                   .replace("\f", "\\f")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }
}