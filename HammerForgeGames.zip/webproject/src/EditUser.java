import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EditUser")
public class EditUser extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String managerId = request.getParameter("managerId");
            String oldCustomerId = request.getParameter("oldCustomerId");
            String newCustomerId = request.getParameter("newCustomerId");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            String phoneNumber = request.getParameter("phoneNumber");

            // Validate manager permissions
            if (Integer.parseInt(managerId) >= Integer.parseInt(oldCustomerId) ||
                Integer.parseInt(managerId) >= Integer.parseInt(newCustomerId)) {
                out.println("{\"success\": false, \"error\": \"Unauthorized to edit this account\"}");
                return;
            }

            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            // Check if new ID exists (if changing ID)
            if (!oldCustomerId.equals(newCustomerId)) {
                String checkIdSql = "SELECT customerID FROM customerTable WHERE customerID = ?";
                stmt = connection.prepareStatement(checkIdSql);
                stmt.setInt(1, Integer.parseInt(newCustomerId));
                rs = stmt.executeQuery();

                if (rs.next()) {
                    out.println("{\"success\": false, \"error\": \"New customer ID already exists\"}");
                    return;
                }
            }

            // Check if email exists (if changing email)
            String checkEmailSql = "SELECT customerID FROM customerTable WHERE email = ? AND customerID != ?";
            stmt = connection.prepareStatement(checkEmailSql);
            stmt.setString(1, email);
            stmt.setInt(2, Integer.parseInt(oldCustomerId));
            rs = stmt.executeQuery();

            if (rs.next()) {
                out.println("{\"success\": false, \"error\": \"Email already exists\"}");
                return;
            }

            // Update user
            String updateSql = "UPDATE customerTable SET customerID = ?, firstName = ?, lastName = ?, " +
                             "email = ?, phoneNumber = ? WHERE customerID = ?";
            stmt = connection.prepareStatement(updateSql);
            stmt.setInt(1, Integer.parseInt(newCustomerId));
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setString(4, email);
            stmt.setString(5, phoneNumber.replaceAll("[^0-9]", ""));
            stmt.setInt(6, Integer.parseInt(oldCustomerId));

            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                out.println("{\"success\": false, \"error\": \"Failed to update user\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}