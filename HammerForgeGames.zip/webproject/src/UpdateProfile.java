import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateProfile")
public class UpdateProfile extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UpdateProfile() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String customerID = request.getParameter("customerID");
        String field = request.getParameter("field");
        String value = request.getParameter("value");
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (customerID == null || field == null || value == null) {
            response.setStatus(400);
            out.println("{\"success\": false, \"error\": \"Missing required parameters\"}");
            return;
        }

        // Validate field name to prevent SQL injection
        if (!isValidFieldName(field)) {
            response.setStatus(400);
            out.println("{\"success\": false, \"error\": \"Invalid field name\"}");
            return;
        }

        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            DBConnection.getDBConnection();
            connection = DBConnection.connection;

            String sql = "UPDATE customerTable SET " + field + " = ? WHERE customerID = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, value);
            stmt.setString(2, customerID);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.println("{\"success\": true}");
            } else {
                response.setStatus(404);
                out.println("{\"success\": false, \"error\": \"Update failed\"}");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(500);
            out.println("{\"success\": false, \"error\": \"Database error: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(500);
            out.println("{\"success\": false, \"error\": \"Server error\"}");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isValidFieldName(String field) {
        // List of valid field names from the database
        String[] validFields = {
            "firstName", "lastName", "email", "phoneNumber",
            "streetAddress", "city", "state", "zipCode",
            "cardNumber", "cardDate", "cardCVC"
        };
        
        for (String validField : validFields) {
            if (validField.equals(field)) {
                return true;
            }
        }
        return false;
    }
}