// Auth state management
function updateAuthUI() {
  const authSection = document.getElementById('auth-section');
  const isLoggedIn = sessionStorage.getItem('customerID') !== null;
  const isManager = isLoggedIn && parseInt(sessionStorage.getItem('customerID')) <= 100;

  if (isLoggedIn) {
    const firstName = sessionStorage.getItem('firstName');
    authSection.innerHTML = `
      <div class="dropdown">
        <button class="dropbtn auth-dropbtn">${firstName} ▼</button>
        <div class="dropdown-content">
          <a href="profile.html">My Profile</a>
          <a href="cart.html" class="cart-menu-item">🛒 My Cart</a>
          ${isManager ? '<a href="accountManager.html">👥 Manager</a>' : ''}
          <button onclick="logout()" class="dropdown-btn">Log Out</button>
        </div>
      </div>
    `;
  } else {
    authSection.innerHTML = `
      <div class="dropdown">
        <button class="dropbtn auth-dropbtn">Account ▼</button>
        <div class="dropdown-content">
          <a href="logIn.html">Log In</a>
          <a href="signIn.html">Sign Up</a>
        </div>
      </div>
    `;
  }

  // Add click handler for new dropdown
  const authDropBtn = document.querySelector('.auth-dropbtn');
  if (authDropBtn) {
    authDropBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      authDropBtn.nextElementSibling.classList.toggle('show');
    });
  }

  // Update body class for conditional styling
  document.body.classList.toggle('logged-in', isLoggedIn);
}

function logout() {
  sessionStorage.clear();
  updateAuthUI();
  window.location.href = 'home.html';
}

// Check if user is logged in and redirect if trying to access auth pages
function checkAuthPages() {
  const isLoggedIn = sessionStorage.getItem('customerID') !== null;
  const isAuthPage = window.location.pathname.includes('logIn.html') || 
                    window.location.pathname.includes('signIn.html');
  
  if (isLoggedIn && isAuthPage) {
    window.location.href = 'home.html';
  }
}

function setFontSize(size) {
  resizableContent.style.fontSize = size + '%';
  fontSizeValue.textContent = size + '%';
  localStorage.setItem('fontSize', size);

  // Update modal font sizes
  const modals = document.querySelectorAll('.modal-content');
  modals.forEach(modal => {
    modal.style.fontSize = size + '%';
  });
}

// Close dropdowns when clicking outside
window.addEventListener('click', function(event) {
  if (!event.target.matches('.auth-dropbtn')) {
    const dropdowns = document.getElementsByClassName('dropdown-content');
    for (const dropdown of dropdowns) {
      if (dropdown.classList.contains('show')) {
        dropdown.classList.remove('show');
      }
    }
  }
});

// Call updateAuthUI when the page loads
document.addEventListener('DOMContentLoaded', () => {
  updateAuthUI();
  checkAuthPages();
});