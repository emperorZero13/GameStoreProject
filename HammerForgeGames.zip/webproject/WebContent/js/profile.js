// Validation functions
function validatePhoneNumber(phone) {
  const phoneRegex = /^\(\d{3}\) \d{3}-\d{4}$/;
  return phoneRegex.test(phone);
}

function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validateZipCode(zipCode) {
  const zipRegex = /^\d{5}$/;
  return zipRegex.test(zipCode);
}

function validateCardNumber(cardNumber) {
  const cardRegex = /^\d{4} \d{4} \d{4} \d{4}$/;
  return cardRegex.test(cardNumber);
}

function validateCardDate(date) {
  const dateRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
  return dateRegex.test(date);
}

// Format input values
function formatPhoneNumber(input) {
  let value = input.replace(/\D/g, '');
  if (value.length >= 6) {
    value = '(' + value.slice(0, 3) + ') ' + value.slice(3, 6) + '-' + value.slice(6);
  } else if (value.length >= 3) {
    value = '(' + value.slice(0, 3) + ') ' + value.slice(3);
  } else if (value.length > 0) {
    value = '(' + value;
  }
  return value;
}

function formatCardNumber(input) {
  let value = input.replace(/\D/g, '');
  return value.replace(/(\d{4})/g, '$1 ').trim();
}

function formatCardDate(input) {
  let value = input.replace(/\D/g, '');
  if (value.length >= 2) {
    value = value.slice(0, 2) + '/' + value.slice(2);
  }
  return value;
}

// Update profile field
async function updateField(field, value, validation = null) {
  if (validation && !validation(value)) {
    throw new Error('Invalid format');
  }

  // For phone number, remove formatting before sending to server
  if (field === 'phoneNumber') {
    value = value.replace(/\D/g, '');
  }
  // For card number, remove spaces before sending to server
  if (field === 'cardNumber') {
    value = value.replace(/\s/g, '');
  }

  try {
    const response = await fetch('UpdateProfile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `customerID=${encodeURIComponent(sessionStorage.getItem('customerID'))}&field=${encodeURIComponent(field)}&value=${encodeURIComponent(value)}`
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Update failed');
    }

    // Update session storage for relevant fields
    if (['firstName', 'lastName', 'email'].includes(field)) {
      sessionStorage.setItem(field, value);
    }

    return true;
  } catch (error) {
    console.error('Update error:', error);
    throw error;
  }
}

// Modal functionality
const modal = document.getElementById('editModal');
const modalForm = document.getElementById('modalForm');
const modalInput = document.getElementById('modalInput');
const modalLabel = document.getElementById('modalLabel');
const modalClose = document.querySelector('.modal-close');

// Store modal state in an object
const modalState = {
  field: null,
  validation: null,
  formatter: null
};

function showModal(field, currentValue, label, validation = null, formatter = null) {
  // Update modal state
  modalState.field = field;
  modalState.validation = validation;
  modalState.formatter = formatter;
  
  modalLabel.textContent = `Edit ${label}`;
  
  // For card number, show full number in edit mode
  if (field === 'cardNumber') {
    // Remove the **** mask for editing
    currentValue = currentValue.replace(/\*+/g, '');
  }
  
  modalInput.value = currentValue;
  
  // Remove any existing input event listeners
  const newModalInput = modalInput.cloneNode(true);
  modalInput.parentNode.replaceChild(newModalInput, modalInput);
  modalForm.querySelector('input').focus();
  
  // Add new formatter if provided
  if (formatter) {
    newModalInput.addEventListener('input', (e) => {
      e.target.value = formatter(e.target.value);
    });
  }
  
  modal.classList.add('active');
}

function closeModal() {
  modal.classList.remove('active');
  // Clear modal state
  modalState.field = null;
  modalState.validation = null;
  modalState.formatter = null;
  modalInput.value = '';
}

modalClose.addEventListener('click', closeModal);
modal.addEventListener('click', (e) => {
  if (e.target === modal) closeModal();
});

modalForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  // Get values from modal state instead of variables
  const field = modalState.field;
  const value = modalForm.querySelector('input').value;
  const validation = modalState.validation;
  
  if (!field) {
    console.error('No field specified');
    return;
  }
  
  const element = document.querySelector(`[data-field="${field}"]`);
  if (!element) {
    console.error('Element not found');
    return;
  }
  
  try {
    if (validation && !validation(value)) {
      throw new Error('Invalid format');
    }
    
    await updateField(field, value, validation);
    
    // Update display value
    if (field === 'cardNumber') {
      element.textContent = '****-****-****-' + value.replace(/\D/g, '').slice(-4);
    } else {
      element.textContent = value;
    }
    
    element.classList.add('update-success');
    setTimeout(() => element.classList.remove('update-success'), 1500);
    closeModal();
  } catch (error) {
    element.classList.add('update-error');
    setTimeout(() => element.classList.remove('update-error'), 1500);
    alert('Update failed: ' + error.message);
  }
});

// Initialize edit buttons
function initializeEditButtons() {
  const editableFields = [
    { selector: '[data-field="firstName"]', field: 'firstName', label: 'First Name' },
    { selector: '[data-field="lastName"]', field: 'lastName', label: 'Last Name' },
    { selector: '[data-field="email"]', field: 'email', label: 'Email', validation: validateEmail },
    { selector: '[data-field="phoneNumber"]', field: 'phoneNumber', label: 'Phone Number', validation: validatePhoneNumber, formatter: formatPhoneNumber },
    { selector: '[data-field="streetAddress"]', field: 'streetAddress', label: 'Street Address' },
    { selector: '[data-field="city"]', field: 'city', label: 'City' },
    { selector: '[data-field="state"]', field: 'state', label: 'State' },
    { selector: '[data-field="zipCode"]', field: 'zipCode', label: 'ZIP Code', validation: validateZipCode },
    { selector: '[data-field="cardNumber"]', field: 'cardNumber', label: 'Card Number', validation: validateCardNumber, formatter: formatCardNumber },
    { selector: '[data-field="cardDate"]', field: 'cardDate', label: 'Card Expiration', validation: validateCardDate, formatter: formatCardDate }
  ];

  editableFields.forEach(({ selector, field, label, validation, formatter }) => {
    const element = document.querySelector(selector);
    if (element) {
      const editButton = document.createElement('button');
      editButton.textContent = '✏️';
      editButton.className = 'edit-button';
      editButton.addEventListener('click', () => {
        showModal(field, element.textContent, label, validation, formatter);
      });
      element.parentNode.appendChild(editButton);
    }
  });
}